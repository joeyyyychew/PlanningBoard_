---
name: inbox-analysis-dashboard
description: Use for maintaining, auditing, or updating the Scale Story Inbox Analysis dashboard connected to ManyChat webhook/external request data. Trigger when working on PM count, true interaction, Pending, After Payment/AO Flow, Total Sales, customer lists, blocker analysis, RUN behavior, ManyChat External Request setup, or syncing reports for the three Scale Story channels.
---

# Inbox Analysis Dashboard

## Purpose

Maintain the Scale Story Inbox Analysis dashboard without changing confirmed UI, navigation, or unrelated tools. The dashboard must show accurate daily ManyChat analysis for three channels and use dashboard order records for Total Sales.

## Channels

- `fb108701968299986` — Scalestory - 天然胶原蛋白 — `Knee 990 MC`
- `fb1177107122151553` — 鳞记 - 天然胶原蛋白 — `Main Front`
- `fb701760706347255` — 鳞记 SG — `SG 997 WA`

## Dashboard structure

- Inbox Analysis has an overview page that totals all three channels.
- Inbox Analysis dropdown keeps the three individual channel pages.
- Tools pages (`Order Key-In`, `Broadcast Planning`) are part of the same dashboard shell, not separate websites.
- Sidebar behavior must remain stable: no unexpected page flashes, no auto-opening dropdowns except user action, no jumping to old designs.

## Core data rules

### PM count

- PM count is based on a ManyChat entry/subscribed event for that date.
- Count each customer once per channel per date, using contact id / WhatsApp id / Messenger id when available; fall back to normalized name only when there is no stable id.
- Ad entry phrases count as PM/source entry but not true interaction.
- Repeated ad entry phrases from the same customer must not increase PM count.

### True interaction

Count as interaction only when the customer sends real text or voice.

Do not count these as interaction:

- Button clicks / quick replies / menu selections.
- Region buttons such as `西马`, `东马`.
- Entry/ad phrases such as `能帮我查看一件商品的价格吗？`, `Can I make a purchase?`, `我要了解最新优惠`, `👉🏼我想了解养颜系列～`, or similar first-step ad copy.
- Automated flow messages sent by the page.

Voice messages should be shown as `语音` if the dashboard cannot transcribe content. Do not show raw audio links as the message content.

### Pending

- Pending means the customer entered the pending/order flow or received the corresponding pending marker for that channel/date.
- Pending must be deducted when the same customer later receives an After Payment/AO Flow, even if the pending date was earlier.
- Do not use generic `Pending` labels alone as final proof when flow event data is available.

### After Payment / AO

- After Payment is counted by the date the After Payment/AO Flow was sent, not by paid/purchased labels.
- Customers can become After Payment on a different date from their Pending date.
- Labels such as Paid/Purchased may be old labels and must not be used as same-day order proof.
- Include alternate language/payment flows such as `after payment [ENG]` when configured.

### Don't Disturb

- Track `Do Not Disturb`, `Don't Disturb`, `Dont Disturb` tags in summary.
- Exclude Don't Disturb contacts from unreplied/follow-up style metrics.

### Blocker analysis / 未下单卡点

- Read actual customer messages when available.
- Write blockers in plain, natural Chinese.
- Focus on why customers have not ordered: price, package unclear, waiting, voice needs manual listening, asked for follow-up, etc.
- Do not summarize automation steps or tag changes as blockers.

### Inbox open links

- Every customer row should prefer a stable ManyChat contact id / subscriber id / WhatsApp id / Messenger id.
- Both WhatsApp and Messenger users must be openable from Dashboard whenever a stable id exists.
- If id is missing, show a safe search/open fallback rather than pretending the direct inbox link is exact.

## Total Sales rule

- Inbox Analysis `Total Sales` must use dashboard Order Key-In records only.
- Do not calculate Total Sales from Google Sheet scans during normal use.
- Deleted dashboard orders must no longer count in Total Sales.
- Overview Total Sales can break down by channel. Individual channel pages should show only that channel's sales.
- Google Sheet is a write/sync destination, not the dashboard source of truth, except for explicit one-time recovery requested by the user.

## RUN behavior

- RUN on overview must update all three channels.
- RUN on an individual channel updates that channel.
- Switching sidebar/page/channel must not auto-refresh ManyChat data.
- Browser refresh may load the latest state once, then the dashboard must hold that state until RUN/manual update/mutation.
- Do not rely on Codex scanning ManyChat manually for normal RUN results. The intended production path is ManyChat External Request/API token → hosted dashboard/server/database → report.

## ManyChat External Request expectations

For each important flow:

- Add External Request at actual event points that can prove PM, customer text/voice, pending, or after-payment flow sent.
- Do not add a global `Any message` trigger if it would cause customer journeys to jump/interrupt.
- Prefer silent tracking actions or flow-end/customer-input points that do not affect customer-facing flow behavior.
- If a flow is only a pass-through and the customer cannot stop or speak there, it does not need tracking there.

Expected event types:

- PM/subscribed/source entry event.
- Customer real message / voice event.
- Pending/order flow event.
- After Payment/AO Flow sent event.
- Tag sync events for special tags such as RM4.90 DRINK, FreeTesting, Don't Disturb.

## Change safety

When editing the dashboard:

- Preserve confirmed design, layout, sidebar behavior, and tools unless the user explicitly asks to change them.
- Apply design-system or refresh fixes across all pages, not one isolated page.
- Avoid file URL testing as the source of truth; test via the local server URL.
- Validate JavaScript syntax for `index.html`, `order-key-in.html`, `broadcast-planning.html`, and `dashboard-shell.js` after changes.
- Run the public build before deployment when relevant.

## Common validation checklist

Before saying a fix is done:

1. Test/inspect overview, each channel page, Order Key-In, and Broadcast Planning.
2. Confirm date stays correct after refresh and sidebar switching.
3. Confirm RUN does not overwrite accurate channel data with stale placeholders.
4. Confirm Total Sales matches dashboard order records for the selected date.
5. Confirm deleted order records do not reappear or count again.
6. Confirm customer lists have names and open inbox links where ids exist.
7. Confirm Broadcast Planning sorting and sheet sync behavior are unchanged unless requested.
