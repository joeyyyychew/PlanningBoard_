# Known ManyChat flow context

Use these as historical context only. Always verify current flow configuration in ManyChat before claiming a flow is fully set up.

## Page 1 — Scalestory / Knee 990 MC

Account: `fb108701968299986`

Important flow categories:

- WhatsApp default reply entry flow.
- Step 2 / Step 3 product education flows.
- Sequence follow-up flows.
- Pending/order flows.
- After Payment / AO flows including `after payment [ENG]`.
- Additional flow previously mentioned: `content20260604155122_204713`.

## Page 2 — Main Front

Account: `fb1177107122151553`

Important flow categories:

- Entry/default reply flows.
- Common folders provided by the user.
- Pending/order flows.
- After Payment flows.

Do not count `Purchased` label alone as same-day After Payment.

## Page 3 — SG 997 WA

Account: `fb701760706347255`

Important flow categories:

- WhatsApp default reply entry flow.
- Newly added entry/product flows.
- Pending/order flows.
- After Payment flows.

Do not count `paid` label alone as same-day After Payment.
